﻿namespace Tic_Tac_Toe
{
    partial class tictactoe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bttnA1 = new System.Windows.Forms.Button();
            this.bttnA2 = new System.Windows.Forms.Button();
            this.bttnA3 = new System.Windows.Forms.Button();
            this.bttnB3 = new System.Windows.Forms.Button();
            this.bttnB1 = new System.Windows.Forms.Button();
            this.bttnB2 = new System.Windows.Forms.Button();
            this.bttnC2 = new System.Windows.Forms.Button();
            this.bttnC3 = new System.Windows.Forms.Button();
            this.bttnC1 = new System.Windows.Forms.Button();
            this.newBtn = new System.Windows.Forms.Button();
            this.resetBtn = new System.Windows.Forms.Button();
            this.exitBtn = new System.Windows.Forms.Button();
            this.XWinLbl = new System.Windows.Forms.Label();
            this.tieLbl = new System.Windows.Forms.Label();
            this.OWinLbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // bttnA1
            // 
            this.bttnA1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnA1.Location = new System.Drawing.Point(12, 12);
            this.bttnA1.Name = "bttnA1";
            this.bttnA1.Size = new System.Drawing.Size(111, 106);
            this.bttnA1.TabIndex = 0;
            this.bttnA1.UseVisualStyleBackColor = true;
            this.bttnA1.Click += new System.EventHandler(this.button_click);
            // 
            // bttnA2
            // 
            this.bttnA2.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnA2.Location = new System.Drawing.Point(129, 12);
            this.bttnA2.Name = "bttnA2";
            this.bttnA2.Size = new System.Drawing.Size(111, 106);
            this.bttnA2.TabIndex = 1;
            this.bttnA2.UseVisualStyleBackColor = true;
            this.bttnA2.Click += new System.EventHandler(this.button_click);
            // 
            // bttnA3
            // 
            this.bttnA3.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnA3.Location = new System.Drawing.Point(246, 12);
            this.bttnA3.Name = "bttnA3";
            this.bttnA3.Size = new System.Drawing.Size(111, 106);
            this.bttnA3.TabIndex = 2;
            this.bttnA3.UseVisualStyleBackColor = true;
            this.bttnA3.Click += new System.EventHandler(this.button_click);
            // 
            // bttnB3
            // 
            this.bttnB3.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnB3.Location = new System.Drawing.Point(246, 124);
            this.bttnB3.Name = "bttnB3";
            this.bttnB3.Size = new System.Drawing.Size(111, 106);
            this.bttnB3.TabIndex = 3;
            this.bttnB3.UseVisualStyleBackColor = true;
            this.bttnB3.Click += new System.EventHandler(this.button_click);
            // 
            // bttnB1
            // 
            this.bttnB1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnB1.Location = new System.Drawing.Point(12, 124);
            this.bttnB1.Name = "bttnB1";
            this.bttnB1.Size = new System.Drawing.Size(111, 106);
            this.bttnB1.TabIndex = 4;
            this.bttnB1.UseVisualStyleBackColor = true;
            this.bttnB1.Click += new System.EventHandler(this.button_click);
            // 
            // bttnB2
            // 
            this.bttnB2.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnB2.Location = new System.Drawing.Point(129, 124);
            this.bttnB2.Name = "bttnB2";
            this.bttnB2.Size = new System.Drawing.Size(111, 106);
            this.bttnB2.TabIndex = 5;
            this.bttnB2.UseVisualStyleBackColor = true;
            this.bttnB2.Click += new System.EventHandler(this.button_click);
            // 
            // bttnC2
            // 
            this.bttnC2.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnC2.Location = new System.Drawing.Point(129, 236);
            this.bttnC2.Name = "bttnC2";
            this.bttnC2.Size = new System.Drawing.Size(111, 106);
            this.bttnC2.TabIndex = 6;
            this.bttnC2.UseVisualStyleBackColor = true;
            this.bttnC2.Click += new System.EventHandler(this.button_click);
            // 
            // bttnC3
            // 
            this.bttnC3.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnC3.Location = new System.Drawing.Point(246, 236);
            this.bttnC3.Name = "bttnC3";
            this.bttnC3.Size = new System.Drawing.Size(111, 106);
            this.bttnC3.TabIndex = 7;
            this.bttnC3.UseVisualStyleBackColor = true;
            this.bttnC3.Click += new System.EventHandler(this.button_click);
            // 
            // bttnC1
            // 
            this.bttnC1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttnC1.Location = new System.Drawing.Point(12, 236);
            this.bttnC1.Name = "bttnC1";
            this.bttnC1.Size = new System.Drawing.Size(111, 106);
            this.bttnC1.TabIndex = 8;
            this.bttnC1.UseVisualStyleBackColor = true;
            this.bttnC1.Click += new System.EventHandler(this.button_click);
            // 
            // newBtn
            // 
            this.newBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.newBtn.Location = new System.Drawing.Point(12, 370);
            this.newBtn.Name = "newBtn";
            this.newBtn.Size = new System.Drawing.Size(111, 53);
            this.newBtn.TabIndex = 9;
            this.newBtn.Text = "New Game";
            this.newBtn.UseVisualStyleBackColor = true;
            this.newBtn.Click += new System.EventHandler(this.newBtn_Click);
            // 
            // resetBtn
            // 
            this.resetBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.resetBtn.Location = new System.Drawing.Point(129, 370);
            this.resetBtn.Name = "resetBtn";
            this.resetBtn.Size = new System.Drawing.Size(111, 53);
            this.resetBtn.TabIndex = 10;
            this.resetBtn.Text = "Reset";
            this.resetBtn.UseVisualStyleBackColor = true;
            this.resetBtn.Click += new System.EventHandler(this.resetBtn_Click);
            // 
            // exitBtn
            // 
            this.exitBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.exitBtn.Location = new System.Drawing.Point(246, 370);
            this.exitBtn.Name = "exitBtn";
            this.exitBtn.Size = new System.Drawing.Size(111, 53);
            this.exitBtn.TabIndex = 11;
            this.exitBtn.Text = "Exit";
            this.exitBtn.UseVisualStyleBackColor = true;
            this.exitBtn.Click += new System.EventHandler(this.exitBtn_Click);
            // 
            // XWinLbl
            // 
            this.XWinLbl.Font = new System.Drawing.Font("Courier New", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.XWinLbl.Location = new System.Drawing.Point(363, 57);
            this.XWinLbl.Name = "XWinLbl";
            this.XWinLbl.Size = new System.Drawing.Size(146, 34);
            this.XWinLbl.TabIndex = 12;
            this.XWinLbl.Text = "X Wins :   ";
            // 
            // tieLbl
            // 
            this.tieLbl.Font = new System.Drawing.Font("Courier New", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tieLbl.Location = new System.Drawing.Point(396, 162);
            this.tieLbl.Name = "tieLbl";
            this.tieLbl.Size = new System.Drawing.Size(113, 31);
            this.tieLbl.TabIndex = 13;
            this.tieLbl.Text = "Ties :   ";
            // 
            // OWinLbl
            // 
            this.OWinLbl.Font = new System.Drawing.Font("Courier New", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OWinLbl.Location = new System.Drawing.Point(363, 274);
            this.OWinLbl.Name = "OWinLbl";
            this.OWinLbl.Size = new System.Drawing.Size(157, 36);
            this.OWinLbl.TabIndex = 14;
            this.OWinLbl.Text = "O Wins :   ";
            // 
            // tictactoe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(649, 450);
            this.Controls.Add(this.OWinLbl);
            this.Controls.Add(this.tieLbl);
            this.Controls.Add(this.XWinLbl);
            this.Controls.Add(this.exitBtn);
            this.Controls.Add(this.resetBtn);
            this.Controls.Add(this.newBtn);
            this.Controls.Add(this.bttnC1);
            this.Controls.Add(this.bttnC3);
            this.Controls.Add(this.bttnC2);
            this.Controls.Add(this.bttnB2);
            this.Controls.Add(this.bttnB1);
            this.Controls.Add(this.bttnB3);
            this.Controls.Add(this.bttnA3);
            this.Controls.Add(this.bttnA2);
            this.Controls.Add(this.bttnA1);
            this.Name = "tictactoe";
            this.Text = "TicTacToe";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button bttnA1;
        private System.Windows.Forms.Button bttnA2;
        private System.Windows.Forms.Button bttnA3;
        private System.Windows.Forms.Button bttnB3;
        private System.Windows.Forms.Button bttnB1;
        private System.Windows.Forms.Button bttnB2;
        private System.Windows.Forms.Button bttnC2;
        private System.Windows.Forms.Button bttnC3;
        private System.Windows.Forms.Button bttnC1;
        private System.Windows.Forms.Button newBtn;
        private System.Windows.Forms.Button resetBtn;
        private System.Windows.Forms.Button exitBtn;
        private System.Windows.Forms.Label XWinLbl;
        private System.Windows.Forms.Label tieLbl;
        private System.Windows.Forms.Label OWinLbl;
    }
}

